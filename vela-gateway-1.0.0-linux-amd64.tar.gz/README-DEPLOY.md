# Vela Gateway — 部署包 (1.0.0, linux/amd64)

单二进制同时提供 API 与前端 SPA。默认读取 `configs/config.yaml`(profile=prod → MySQL)。
敏感配置一律走环境变量,不要写进 config.yaml。

## 1. 准备
- 一个可连接的 MySQL 8 实例,并创建空库(库名与 DSN 一致):
  `CREATE DATABASE vela_gateway DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
- 复制 `vela.env.example` 为 `vela.env` 并填写(`chmod 600 vela.env`):
  - `VELA_JWT_SECRET`:`openssl rand -hex 32`(≥32 位,否则拒绝启动)
  - `VELA_MYSQL_DSN`:`user:pass@tcp(host:3306)/vela_gateway?charset=utf8mb4&parseTime=true&loc=Local`

## 2. 迁移表结构(幂等,可重复执行)
```
set -a; . ./vela.env; set +a
./vela-gateway migrate
```
迁移记录在 `schema_migrations` 表,已应用的版本会跳过。

## 3. 初始化引用数据 + 平台管理员(仅首次)
```
./vela-gateway init --admin-email you@corp.io --admin-password 'A-Strong-Passw0rd!'
```
(`init` 也会先跑迁移;口令需 ≥12 位且含大小写/数字/符号中 ≥3 类。)

## 4. 运行
```
./vela-gateway -config configs/config.yaml
```
默认监听 `:8080`,同源提供 SPA。生产建议:
- 前置反向代理终止 TLS,或配 `VELA_TLS_CERT`/`VELA_TLS_KEY` 让网关直接跑 HTTPS。
- 用 systemd 托管:见 `deploy/vela-gateway.service`。

## 常用命令
- `./vela-gateway version`   查看版本
- `./vela-gateway migrate`   仅应用待执行的迁移
- `./vela-gateway init ...`  迁移 + 引用数据 + 管理员
