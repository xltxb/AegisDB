function o(n){return typeof window>"u"?!0:window.confirm(n)}export{o as c};
